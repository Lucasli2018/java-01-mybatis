package com.kkb.mybatis.session;

import java.util.List;

public interface Executor {

	<T> List<T> query(MappedStatement mappedStatement,Object args);
}
