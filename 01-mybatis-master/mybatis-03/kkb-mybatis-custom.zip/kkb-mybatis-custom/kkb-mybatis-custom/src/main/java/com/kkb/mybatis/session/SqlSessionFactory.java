package com.kkb.mybatis.session;

public interface SqlSessionFactory {

	SqlSession openSession();

}
