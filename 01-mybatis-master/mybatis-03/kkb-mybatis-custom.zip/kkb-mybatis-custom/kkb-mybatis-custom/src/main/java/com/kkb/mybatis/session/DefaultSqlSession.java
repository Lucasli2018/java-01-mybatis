package com.kkb.mybatis.session;

import java.util.List;

public class DefaultSqlSession implements SqlSession {
	private Configuration configuration;

	public DefaultSqlSession(Configuration configuration) {
		this.configuration = configuration;
	}

	@Override
	public <T> T selectOne(String statementId, Object arg) {
		List<T> list = selectList(statementId, arg);
		if (list != null && list.size() == 1) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public <E> List<E> selectList(String statementId, Object arg) {
		MappedStatement ms = configuration.getMappedStatement(statementId);
		Executor executor = new SimpleExecutor();
		executor.query(ms, arg);
		return null;
	}

}
