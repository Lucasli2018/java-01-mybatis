package com.kkb.mybatis.parser;

import com.kkb.mybatis.session.SqlSource;

public class SqlSourceParser {

	private String sqlText;

	private Class<?> parameterTypeClass;

	public SqlSourceParser(String sqlText, Class<?> parameterTypeClass) {
		this.sqlText = sqlText;
		this.parameterTypeClass = parameterTypeClass;
	}

	public SqlSource parse() {
		//处理${}
		
		//处理#{}
		
		return null;
	}

}
