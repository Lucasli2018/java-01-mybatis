package com.kkb.mybatis.builder;

import java.io.InputStream;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;

import com.kkb.mybatis.parser.DocumentParser;
import com.kkb.mybatis.parser.GenericTokenParser;
import com.kkb.mybatis.parser.ParameterMappingTokenHandler;
import com.kkb.mybatis.session.Configuration;
import com.kkb.mybatis.session.DefaultSqlSource;
import com.kkb.mybatis.session.MappedStatement;
import com.kkb.mybatis.session.SqlSource;

public class XMLMapperBuilder {
	private Configuration configuration;

	private InputStream inputStream;

	public XMLMapperBuilder(InputStream inputStream, Configuration configuration) {
		this.configuration = configuration;
		this.inputStream = inputStream;

	}

	public void parse() {
		try {
			Document document = DocumentParser.getDocument(inputStream);

			parseMapperElement(document.selectSingleNode("/mapper"));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	private void parseMapperElement(Node mapperNode) {

		if (mapperNode == null) {
			return;
		}
		Element rootElement = (Element) mapperNode;

		String namespace = rootElement.attributeValue("namespace");
		if (namespace == null || namespace.equals("")) {
			return;
		}

		buildStatementFromContext(rootElement.selectNodes("select"));

	}

	private void buildStatementFromContext(List<Node> nodes) {
		MappedStatement ms;
		for (Node node : nodes) {
			Element element = (Element) node;

			String id = element.attributeValue("id");

			String parameterType = element.attributeValue("parameterType");
			Class<?> parameterTypeClass = resolveClass(parameterType);

			String resultType = element.attributeValue("resultType");
			Class<?> resultTypeClass = resolveClass(resultType);

			String statementType = element.attributeValue("statementType");

			SqlSource sqlSource = createSqlSource(element, parameterTypeClass);

			ms = new MappedStatement(configuration, id, parameterTypeClass, resultTypeClass, sqlSource, statementType);
			configuration.addMappedStatement(ms);
		}
	}

	private SqlSource createSqlSource(Node context, Class<?> parameterTypeClass) {

		//如果带有${}的话，先去处理${}，再去处理#{}
		
		ParameterMappingTokenHandler handler = new ParameterMappingTokenHandler(configuration, parameterTypeClass);
		// 创建分词解析器
		GenericTokenParser parser = new GenericTokenParser("#{", "}", handler);
		// 解析#{}
		String originalSql = context.getText();
		String sql = parser.parse(originalSql);

		return new DefaultSqlSource(sql, handler.getParameterMappings());
	}

	private Class<?> resolveClass(String parameterType) {
		try {
			// 最好使用TypeHandlerRegistry集合去匹配parameterType，获取类型
			return Class.forName(parameterType);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

}
