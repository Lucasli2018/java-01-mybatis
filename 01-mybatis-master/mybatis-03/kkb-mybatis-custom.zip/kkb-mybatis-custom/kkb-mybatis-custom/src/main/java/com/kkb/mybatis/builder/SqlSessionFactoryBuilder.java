package com.kkb.mybatis.builder;

import java.io.InputStream;

import com.kkb.mybatis.session.Configuration;
import com.kkb.mybatis.session.DefaultSqlSessionFactory;
import com.kkb.mybatis.session.SqlSessionFactory;

public class SqlSessionFactoryBuilder {

	public SqlSessionFactory build(InputStream inputStream) {
		XMLConfigBuilder parser = new XMLConfigBuilder(inputStream);
		return build(parser.parse());
	}

	public SqlSessionFactory build(Configuration configuration) {

		return new DefaultSqlSessionFactory(configuration);
	}
}
