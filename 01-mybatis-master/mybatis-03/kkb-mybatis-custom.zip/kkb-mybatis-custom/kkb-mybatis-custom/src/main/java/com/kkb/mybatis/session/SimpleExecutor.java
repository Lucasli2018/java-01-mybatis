package com.kkb.mybatis.session;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

public class SimpleExecutor implements Executor {

	@Override
	public <T> List<T> query(MappedStatement mappedStatement, Object parameterObject) {

		try {
			BoundSql boundSql = mappedStatement.getSqlSource().getBoundSQL(parameterObject);
			PreparedStatement preparedStatement = createConnection(mappedStatement, boundSql);
			parameterize(boundSql, preparedStatement,parameterObject);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				ResultSetMetaData metaData = rs.getMetaData();
				int columnCount = metaData.getColumnCount();
				for (int i = 1; i <= columnCount; i++) {
					System.out.println(metaData.getColumnLabel(i) + "---" + rs.getObject(i) + "----"
							+ metaData.getColumnClassName(i));
				}

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	private PreparedStatement createConnection(MappedStatement mappedStatement, BoundSql boundSql) throws SQLException {
		Configuration configuration = mappedStatement.getConfiguration();
		DataSource dataSource = configuration.getDataSource();
		Connection connection = dataSource.getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement(boundSql.getSql());
		return preparedStatement;
	} 

	private void parameterize(BoundSql boundSQL, PreparedStatement preparedStatement, Object parameterObject) {
		try {
			List<ParameterMapping> parameterMappings = boundSQL.getParameterMappings();
			for (int i = 0; i < parameterMappings.size(); i++) {
				ParameterMapping parameterMapping = parameterMappings.get(i);
				if (parameterMapping.getParameterTypeClass().equals(Integer.class)) {
					if (parameterObject instanceof Integer) {
						preparedStatement.setInt(i + 1, (Integer)parameterObject);
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
