package com.kkb.mybatis.parser;

import java.util.List;

import org.dom4j.Node;

public class XPathParser {

	public Node evalNode(Node node, String expression) {
		Node singleNode = node.selectSingleNode(expression);
		return singleNode;
	}

	public List<Node> evalNodes(Node node, String expression) {
		List<Node> nodes = node.selectNodes(expression);
		return nodes;
	}
}
