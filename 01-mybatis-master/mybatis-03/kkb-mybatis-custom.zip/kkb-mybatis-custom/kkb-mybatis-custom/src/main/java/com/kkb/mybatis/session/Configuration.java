package com.kkb.mybatis.session;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

public class Configuration {
	protected Map<String, MappedStatement> mappedStatements = new HashMap<>();

	private DataSource dataSource;

	public MappedStatement getMappedStatement(String statementId) {
		return mappedStatements.get(statementId);
	}

	public void addMappedStatement(MappedStatement mappedStatement) {
		mappedStatements.put(mappedStatement.getId(), mappedStatement);
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

}
