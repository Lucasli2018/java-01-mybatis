package com.kkb.mybatis.parser;

import java.io.InputStream;

import org.dom4j.Document;
import org.dom4j.io.SAXReader;

/**
 * 读取InputStream或者Reader，使用SAX解析，创建Document对象
 * 
 * @author think
 *
 */
public class DocumentParser {

	public static Document getDocument(InputStream inputStream) throws Exception{
		// 创建SaxReader对象
		SAXReader reader = new SAXReader();
		// 读取XML配置文件，返回Document对象
		Document document = reader.read(inputStream);
		return document;
	}
}
