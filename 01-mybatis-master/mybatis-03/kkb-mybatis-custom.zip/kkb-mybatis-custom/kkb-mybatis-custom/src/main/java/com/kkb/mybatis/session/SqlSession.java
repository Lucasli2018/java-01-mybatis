package com.kkb.mybatis.session;

import java.util.List;

public interface SqlSession {

	<T> T selectOne(String statementId,Object arg);
	
	<E> List<E> selectList(String statementId,Object arg);
}
