package com.kkb.mybatis.session;

public interface SqlSource {

	BoundSql getBoundSQL(Object parameter);
}
