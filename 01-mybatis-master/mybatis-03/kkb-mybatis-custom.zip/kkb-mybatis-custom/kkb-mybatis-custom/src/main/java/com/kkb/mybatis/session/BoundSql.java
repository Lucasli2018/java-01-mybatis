package com.kkb.mybatis.session;

import java.util.ArrayList;
import java.util.List;

public class BoundSql {

	private String sql;
	
	private List<ParameterMapping> parameterMappings = new ArrayList<>();

	private Object parameterObject;
	
	public String getSql() {
		return sql;
	}

	public void setSql(String sql) {
		this.sql = sql;
	}

	public List<ParameterMapping> getParameterMappings() {
		return parameterMappings;
	}

	public void addParameterMapping(ParameterMapping parameterMapping) {
		this.parameterMappings.add(parameterMapping);
	}

	public Object getParameterObject() {
		return parameterObject;
	}

	public void setParameterObject(Object parameterObject) {
		this.parameterObject = parameterObject;
	}

	public BoundSql(String sql, List<ParameterMapping> parameterMappings, Object parameterObject) {
		super();
		this.sql = sql;
		this.parameterMappings = parameterMappings;
		this.parameterObject = parameterObject;
	}
	
	
	
}
