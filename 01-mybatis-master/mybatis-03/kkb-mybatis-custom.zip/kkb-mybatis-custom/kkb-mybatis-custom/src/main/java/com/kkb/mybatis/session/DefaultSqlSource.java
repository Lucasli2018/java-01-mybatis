package com.kkb.mybatis.session;

import java.util.List;

public class DefaultSqlSource implements SqlSource {
	private String sql;

	private List<ParameterMapping> parameterMappings;

	public DefaultSqlSource(String sql, List<ParameterMapping> parameterMappings) {
		this.sql = sql;
		this.parameterMappings = parameterMappings;
	}

	@Override
	public BoundSql getBoundSQL(Object parameterObject) {
		return new BoundSql(sql, parameterMappings, parameterObject);
	}

}
