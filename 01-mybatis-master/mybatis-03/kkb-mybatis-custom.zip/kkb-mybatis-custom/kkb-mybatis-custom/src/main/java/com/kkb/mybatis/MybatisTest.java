package com.kkb.mybatis;

import java.io.InputStream;

import org.junit.Test;

import com.kkb.mybatis.builder.SqlSessionFactoryBuilder;
import com.kkb.mybatis.io.Resources;
import com.kkb.mybatis.session.SqlSession;
import com.kkb.mybatis.session.SqlSessionFactory;

public class MybatisTest {

	@Test
	public void test1() throws Exception{
		String resource = "SqlMapConfig.xml";
		InputStream inputStream = Resources.getResourceAsStream(resource);
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Object object = sqlSession.selectOne("findUserById", 1);
	}
}
