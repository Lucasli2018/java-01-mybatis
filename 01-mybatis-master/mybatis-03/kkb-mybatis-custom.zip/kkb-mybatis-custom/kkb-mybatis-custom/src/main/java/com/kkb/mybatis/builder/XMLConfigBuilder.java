package com.kkb.mybatis.builder;

import java.io.InputStream;
import java.util.List;
import java.util.Properties;

import org.apache.commons.dbcp.BasicDataSource;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;

import com.kkb.mybatis.io.Resources;
import com.kkb.mybatis.parser.DocumentParser;
import com.kkb.mybatis.session.Configuration;

/**
 * 用来创建Configuration对象
 * 
 * @author think
 *
 */
public class XMLConfigBuilder {

	private Configuration configuration;

	private InputStream inputStream;

	// private XPathParser xPathParser ;

	public XMLConfigBuilder(InputStream inputStream) {
		configuration = new Configuration();
		this.inputStream = inputStream;
		// xPathParser = new XPathParser();
	}

	public Configuration parse() {
		try {
			Document document = DocumentParser.getDocument(inputStream);
			parseConfiguration(document.selectSingleNode("/configuration"));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return configuration;
	}

	private void parseConfiguration(Node rootElement) {
		// 解析environment标签
		environmentsElement(rootElement.selectSingleNode("environments"));
		System.out.println(rootElement.getName());
		// 解析mappers标签
		mappersElement(rootElement.selectSingleNode("mappers"));
	}

	@SuppressWarnings("unchecked")
	private void mappersElement(Node mappersElement) {
		if (mappersElement == null) {
			return;
		}
		List<Node> nodes = mappersElement.selectNodes("mapper");
		for (Node node : nodes) {
			Element element = (Element) node;
			String resource = element.attributeValue("resource");
			
			InputStream resourceAsStream = Resources.getResourceAsStream(resource);
			
			XMLMapperBuilder xmlMapperBuilder = new XMLMapperBuilder(resourceAsStream,configuration);
			xmlMapperBuilder.parse();
		}
	}

	/**
	 * 解析之后，创建DataSource（DBCP ）
	 * 
	 * @param environmentsElement
	 */
	@SuppressWarnings("unchecked")
	private void environmentsElement(Node environmentsElement) {
		if (environmentsElement == null) {
			return;
		}

		String defaultEnvironmentId = ((Element) environmentsElement).attributeValue("default");

		List<Node> nodes = environmentsElement.selectNodes("environment");

		for (Node node : nodes) {
			Element element = (Element) node;
			String environmentId = element.attributeValue("id");
			if (defaultEnvironmentId.equals(environmentId)) {
				createDataSource(element.selectSingleNode("dataSource"));
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void createDataSource(Node dataSourceElement) {
		if (dataSourceElement == null) {
			return;
		}
		Properties properties = new Properties();
		List<Node> nodes = dataSourceElement.selectNodes("property");
		for (Node node : nodes) {
			Element element = (Element) node;
			properties.setProperty(element.attributeValue("name"), element.attributeValue("value"));
		}
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setDriverClassName(properties.getProperty("driver"));
		dataSource.setUrl(properties.getProperty("url"));
		dataSource.setUsername(properties.getProperty("username"));
		dataSource.setPassword(properties.getProperty("password"));

		configuration.setDataSource(dataSource);
	}
}
