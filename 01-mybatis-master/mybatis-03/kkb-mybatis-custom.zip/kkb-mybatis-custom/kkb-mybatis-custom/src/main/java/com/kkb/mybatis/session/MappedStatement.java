package com.kkb.mybatis.session;

public class MappedStatement {

	private Configuration configuration;

	private String id;

	private Class<?> parameterTypeClass;

	private Class<?> resultTypeClass;

	private SqlSource sqlSource;

	private String statementType;

	public String getStatementType() {
		return statementType;
	}

	public void setStatementType(String statementType) {
		this.statementType = statementType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Class<?> getParameterTypeClass() {
		return parameterTypeClass;
	}

	public void setParameterTypeClass(Class<?> parameterTypeClass) {
		this.parameterTypeClass = parameterTypeClass;
	}

	public Class<?> getResultTypeClass() {
		return resultTypeClass;
	}

	public void setResultTypeClass(Class<?> resultTypeClass) {
		this.resultTypeClass = resultTypeClass;
	}

	public SqlSource getSqlSource() {
		return sqlSource;
	}

	public void setSqlSource(SqlSource sqlSource) {
		this.sqlSource = sqlSource;
	}

	public MappedStatement(Configuration configuration, String id, Class<?> parameterTypeClass,
			Class<?> resultTypeClass, SqlSource sqlSource, String statementType) {
		super();
		this.configuration = configuration;
		this.id = id;
		this.parameterTypeClass = parameterTypeClass;
		this.resultTypeClass = resultTypeClass;
		this.sqlSource = sqlSource;
		this.statementType = statementType;
	}

	public Configuration getConfiguration() {
		return configuration;
	}

	public void setConfiguration(Configuration configuration) {
		this.configuration = configuration;
	}

}
