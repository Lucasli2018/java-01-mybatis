package com.kkb.mybatis.io;

import java.io.InputStream;

/***
 * 加载XML配置文件，获取InputStream或者Reader
 * 
 * @author think
 */
public class Resources {

	public static InputStream getResourceAsStream(String resource) {
		InputStream inputStream = Resources.class.getClassLoader().getResourceAsStream(resource);
		return inputStream;
	}
}
